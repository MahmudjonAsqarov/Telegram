import React, { useState } from 'react';
import '../sidebar/Sidebar.css';
import Personal from '../components/personal/Personal';
import { FiEdit2, FiMenu, FiSearch, FiArrowLeft } from 'react-icons/fi';
import searchResult from '../SEARCH_RESULTS.json';

function Sidebar() {
    const [isFocused, setIsFocused] = useState(false);
    const personalChatData = [
        {
            id: 1,
            username: "Soginboyev Oybek",
            lastMessage: "key={productItem}",
            image: "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcQbnxlR6bxMYeS7ilYQI1A9FfBfybDCKCoWbw&usqp=CAU",
        },
        {
            id: 2,
            username: "Eldorbek oxunov",
            lastMessage: "hello bro",
            image: "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcSN_iqGNdD4GH3TF01wwe0LgIwgwl7pODjSEg&usqp=CAU",
        },
        {
            id: 3,
            username: "Gulomjonov Shohruzbek",
            lastMessage: "please install",
            image: "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcSN_iqGNdD4GH3TF01wwe0LgIwgwl7pODjSEg&usqp=CAU",
        },
        {
            id: 4,
            username: "Soginboyev Oybek",
            lastMessage: "key={productItem}",
            image: "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcQbnxlR6bxMYeS7ilYQI1A9FfBfybDCKCoWbw&usqp=CAU",
        },
        {
            id: 5,
            username: "Eldorbek oxunov",
            lastMessage: "hello bro",
            image: "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcSN_iqGNdD4GH3TF01wwe0LgIwgwl7pODjSEg&usqp=CAU",
        },
        {
            id: 6,
            username: "Gulomjonov Shohruzbek",
            lastMessage: "please install",
            image: "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcSN_iqGNdD4GH3TF01wwe0LgIwgwl7pODjSEg&usqp=CAU",
        },
        {
            id: 7,
            username: "Soginboyev Oybek",
            lastMessage: "key={productItem}",
            image: "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcQbnxlR6bxMYeS7ilYQI1A9FfBfybDCKCoWbw&usqp=CAU",
        },
        {
            id: 8,
            username: "Eldorbek oxunov",
            lastMessage: "hello bro",
            image: "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcSN_iqGNdD4GH3TF01wwe0LgIwgwl7pODjSEg&usqp=CAU",
        },
        {
            id: 9,
            username: "Gulomjonov Shohruzbek",
            lastMessage: "please install",
            image: "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcSN_iqGNdD4GH3TF01wwe0LgIwgwl7pODjSEg&usqp=CAU",
        },
        {
            id: 10,
            username: "Soginboyev Oybek",
            lastMessage: "key={productItem}",
            image: "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcQbnxlR6bxMYeS7ilYQI1A9FfBfybDCKCoWbw&usqp=CAU",
        },
        {
            id: 11,
            username: "Eldorbek oxunov",
            lastMessage: "hello bro",
            image: "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcSN_iqGNdD4GH3TF01wwe0LgIwgwl7pODjSEg&usqp=CAU",
        },
        {
            id: 12,
            username: "Gulomjonov Shohruzbek",
            lastMessage: "please install",
            image: "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcSN_iqGNdD4GH3TF01wwe0LgIwgwl7pODjSEg&usqp=CAU",
        },
        {
            id: 13,
            username: "Gulomjonov Shohruzbek",
            lastMessage: "please install",
            image: "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcSN_iqGNdD4GH3TF01wwe0LgIwgwl7pODjSEg&usqp=CAU",
        },
        {
            id: 14,
            username: "Soginboyev Oybek",
            lastMessage: "key={productItem}",
            image: "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcQbnxlR6bxMYeS7ilYQI1A9FfBfybDCKCoWbw&usqp=CAU",
        },
        {
            id: 15,
            username: "Eldorbek oxunov",
            lastMessage: "hello bro",
            image: "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcSN_iqGNdD4GH3TF01wwe0LgIwgwl7pODjSEg&usqp=CAU",
        },
        {
            id: 16,
            username: "Gulomjonov Shohruzbek",
            lastMessage: "please install",
            image: "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcSN_iqGNdD4GH3TF01wwe0LgIwgwl7pODjSEg&usqp=CAU",
        },
    ]
    const handleNewMessage = (e) => {
        const newChatOptions = document.querySelector('.new__chatOptions');
        newChatOptions.classList.add('new__chatOptionsActive');
    }
    const handleNewMessageHide = (e) => {
        const newChatOptions = document.querySelector('.new__chatOptions');
        newChatOptions.classList.remove('new__chatOptionsActive');
    }
    const handleSearch = (e) => {
        const searchInput = document.querySelector('.search__bar');
        searchInput.classList.add('activeSearch');
        setIsFocused(true);
    }
    const hideSearch = (e) => {
        const searchInput = document.querySelector('.search__bar');
        searchInput.classList.remove('activeSearch');
        setIsFocused(false);
    }
    return (
        <div className="sidebar">
            <div className="sidebar__navigation">
                <div className="hamburger__menu">
                    {!isFocused ? <FiMenu/> : <FiArrowLeft/>}
                </div>
                <div className="search__bar">
                <FiSearch/>
                <input type="text" placeholder="Search" id="search__input" onBlur={hideSearch} onFocus={handleSearch} />
                </div>
            </div>
            {
                isFocused ? 
                <div className="search__results">
                    {
                        searchResult.map(searchItem => (
                            <div className="search__profile">
                                <div className="searchedProfileImage" style={{backgroundImage: `url(${searchItem.profileImage})`}}></div>
                                <p>{searchItem.nickname}</p>
                            </div>
                        ))
                    }
                </div>
                :
                <div className="sidebar__chats">
                    {
                        personalChatData.map(chatInfo =>
                            (
                                <Personal
                                    key={chatInfo.id}
                                    username={chatInfo.username}
                                    lastMessage={chatInfo.lastMessage}
                                    image={chatInfo.image}
                                />
                            )
                        )
                    }
                </div>
            }
            <div className="new__chatOptions">
                <ul className="new__chatCollection">
                    <li>New Channel</li>
                    <li>New Group</li>
                    <li>New Secret Chat</li>
                </ul>
            </div>
            <button className="new" onFocus={handleNewMessage} onBlur={handleNewMessageHide}>
                <FiEdit2/>
            </button>
        </div>
    )
}

export default Sidebar;