import React from 'react'
import '../header/Header.css';

function Header() {
    return (
        <div className="header">
            <h1>salom</h1>
        </div>
    )
}

export default Header
