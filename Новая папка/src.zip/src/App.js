import './App.css';
import Sidebar from './sidebar/Sidebar';

function App() {
  return (
    <div className="App">
        <Sidebar />
    </div>
  );
}

export default App;