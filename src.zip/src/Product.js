import React from 'react'

function Product({ismi}) {
    return (
        <div>
            <h1>{ismi}</h1>
        </div>
    )
}

export default Product
