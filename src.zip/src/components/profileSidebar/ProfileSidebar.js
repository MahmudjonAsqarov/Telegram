import React from 'react';
import './ProfileSidebar.css';

const ProfileSidebar = () => {
    return (
        <div className="profileSidebar">
            <div className="profileSidebar_wrapper">
                <h1>Salommeeeee</h1>
            </div>
        </div>
    )
}

export default ProfileSidebar
